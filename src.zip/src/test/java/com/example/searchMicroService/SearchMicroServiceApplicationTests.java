package com.example.searchMicroService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
